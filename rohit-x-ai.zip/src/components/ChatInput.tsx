import { useState, useRef, useEffect } from "react";
import { Send, Smile, Paperclip, X, Smartphone } from "lucide-react";
import EmojiPicker, { Theme } from "emoji-picker-react";
import { motion, AnimatePresence } from "motion/react";
import MediaControls from "./MediaControls";

interface ChatInputProps {
  onSend: (message: string) => void;
  isLoading: boolean;
  isDarkMode: boolean;
  onOpenCamera: () => void;
  onOpenScreenShare: () => void;
  onOpenMobileFixer: () => void;
}

export default function ChatInput({ onSend, isLoading, isDarkMode, onOpenCamera, onOpenScreenShare, onOpenMobileFixer }: ChatInputProps) {
  const [input, setInput] = useState("");
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const emojiPickerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (emojiPickerRef.current && !emojiPickerRef.current.contains(event.target as Node)) {
        setShowEmojiPicker(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSend = () => {
    if (!input.trim() || isLoading) return;
    onSend(input.trim());
    setInput("");
    setShowEmojiPicker(false);
  };

  const onEmojiClick = (emojiData: any) => {
    setInput((prev) => prev + emojiData.emoji);
  };

  return (
    <footer className="bg-white/80 dark:bg-neutral-900/80 backdrop-blur-xl border-t border-neutral-200 dark:border-neutral-800 p-4 md:p-6 sticky bottom-0 z-20 shadow-2xl">
      <div className="max-w-4xl mx-auto relative">
        <AnimatePresence>
          {showEmojiPicker && (
            <motion.div
              initial={{ opacity: 0, y: 20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 20, scale: 0.95 }}
              ref={emojiPickerRef}
              className="absolute bottom-full mb-4 right-0 z-50 shadow-2xl rounded-2xl overflow-hidden border border-neutral-200 dark:border-neutral-700"
            >
              <EmojiPicker
                onEmojiClick={onEmojiClick}
                theme={isDarkMode ? Theme.DARK : Theme.LIGHT}
                width={320}
                height={400}
                skinTonesDisabled
                searchDisabled
              />
            </motion.div>
          )}
        </AnimatePresence>

        <div className="flex gap-3 items-end">
          <div className="relative flex-1 bg-neutral-100 dark:bg-neutral-800 rounded-2xl border border-neutral-200 dark:border-neutral-700 focus-within:border-orange-500 dark:focus-within:border-orange-500 transition-all shadow-sm">
            <textarea
              rows={1}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder="Rohit se kuch pucho..."
              className="w-full bg-transparent border-none px-6 py-4 pr-24 focus:ring-0 outline-none transition-all text-neutral-800 dark:text-neutral-100 resize-none max-h-32"
              style={{ height: "auto" }}
              onInput={(e) => {
                const target = e.target as HTMLTextAreaElement;
                target.style.height = "auto";
                target.style.height = `${target.scrollHeight}px`;
              }}
            />
            <div className="absolute right-4 bottom-4 flex gap-3 text-neutral-400 dark:text-neutral-500">
              <button
                onClick={onOpenMobileFixer}
                className="hover:text-orange-500 transition-colors p-1"
                title="Mobile Fixer"
              >
                <Smartphone size={22} />
              </button>
              <MediaControls onOpenCamera={onOpenCamera} onOpenScreenShare={onOpenScreenShare} />
              <button 
                onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                className="hover:text-orange-500 transition-colors p-1"
              >
                <Smile size={22} />
              </button>
              <button className="hover:text-neutral-600 dark:hover:text-neutral-300 transition-colors p-1">
                <Paperclip size={22} />
              </button>
            </div>
          </div>
          
          <button
            onClick={handleSend}
            disabled={!input.trim() || isLoading}
            className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all shadow-lg flex-shrink-0 ${
              input.trim() && !isLoading 
                ? "premium-button" 
                : "bg-neutral-200 dark:bg-neutral-800 text-neutral-400 dark:text-neutral-600 cursor-not-allowed"
            }`}
          >
            <Send size={24} />
          </button>
        </div>
      </div>
    </footer>
  );
}
