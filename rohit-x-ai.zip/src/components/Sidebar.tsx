import { motion } from "motion/react";
import { Plus, History, Trash2, X, MessageSquare, Trash } from "lucide-react";

interface Message {
  chat_id?: string;
  role: "user" | "model";
  content: string;
  timestamp?: string;
}

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  onNewChat: () => void;
  onClearAll: () => void;
  history: Message[];
  onDeleteChat: (chatId: string) => void;
}

export default function Sidebar({ isOpen, onClose, onNewChat, onClearAll, history, onDeleteChat }: SidebarProps) {
  // Group history by date
  const groupedHistory = history.reduce((acc: any, msg) => {
    if (msg.role !== "user") return acc;
    const date = msg.timestamp ? new Date(msg.timestamp).toLocaleDateString() : "Today";
    if (!acc[date]) acc[date] = [];
    acc[date].push(msg);
    return acc;
  }, {});

  return (
    <>
      {/* Overlay for mobile */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      <motion.aside
        initial={false}
        animate={{ x: isOpen ? 0 : -320 }}
        className={`fixed top-0 left-0 h-full w-80 bg-white dark:bg-neutral-900 border-r border-neutral-200 dark:border-neutral-800 z-50 flex flex-col shadow-2xl transition-all duration-300 ease-in-out`}
      >
        {/* Sidebar Header */}
        <div className="p-6 flex items-center justify-between border-b border-neutral-100 dark:border-neutral-800">
          <div className="flex items-center gap-2 text-orange-500">
            <MessageSquare size={24} />
            <span className="font-bold text-xl tracking-tight dark:text-white">Rohit X AI</span>
          </div>
          <button onClick={onClose} className="lg:hidden p-2 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-full dark:text-neutral-400">
            <X size={20} />
          </button>
        </div>

        {/* New Chat Button */}
        <div className="p-4">
          <button
            onClick={() => { onNewChat(); onClose(); }}
            className="w-full py-3 px-4 bg-orange-500 hover:bg-orange-600 text-white rounded-xl flex items-center justify-center gap-2 font-semibold transition-all shadow-lg active:scale-95"
          >
            <Plus size={20} />
            New Chat
          </button>
        </div>

        {/* History List */}
        <div className="flex-1 overflow-y-auto px-4 space-y-6 py-4">
          {Object.keys(groupedHistory).length === 0 ? (
            <div className="text-center py-10 opacity-40 dark:text-white">
              <History size={40} className="mx-auto mb-2" />
              <p className="text-sm">No chat history yet</p>
            </div>
          ) : (
            Object.entries(groupedHistory).map(([date, msgs]: [string, any]) => (
              <div key={date} className="space-y-2">
                <h3 className="text-[10px] font-bold uppercase tracking-widest text-neutral-400 dark:text-neutral-500 px-2">
                  {date === new Date().toLocaleDateString() ? "Today" : date}
                </h3>
                {msgs.map((msg: Message, idx: number) => (
                  <div
                    key={msg.chat_id || idx}
                    className="group flex items-center gap-2 p-3 rounded-xl hover:bg-neutral-100 dark:hover:bg-neutral-800 cursor-pointer transition-all border border-transparent hover:border-neutral-200 dark:hover:border-neutral-700"
                  >
                    <MessageSquare size={16} className="text-neutral-400 flex-shrink-0" />
                    <span className="text-sm text-neutral-600 dark:text-neutral-300 truncate flex-1">
                      {msg.content}
                    </span>
                    {msg.chat_id && (
                      <button
                        onClick={(e) => { e.stopPropagation(); onDeleteChat(msg.chat_id!); }}
                        className="opacity-0 group-hover:opacity-100 p-1.5 hover:text-red-500 text-neutral-400 transition-all"
                      >
                        <Trash2 size={14} />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            ))
          )}
        </div>

        {/* Sidebar Footer */}
        <div className="p-4 border-t border-neutral-100 dark:border-neutral-800">
          <button
            onClick={onClearAll}
            className="w-full py-3 px-4 border border-red-200 dark:border-red-900/30 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/10 rounded-xl flex items-center justify-center gap-2 text-sm font-medium transition-all"
          >
            <Trash size={18} />
            Clear All Chats
          </button>
        </div>
      </motion.aside>
    </>
  );
}
