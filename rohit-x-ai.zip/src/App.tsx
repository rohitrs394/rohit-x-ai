import { useState, useEffect, useRef } from "react";
import { Menu, Moon, Sun, Sparkles, Smile, History, Plus, Trash2, Trash, X, MessageSquare, Heart, User, Mic } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import Sidebar from "./components/Sidebar";
import MessageBubble from "./components/MessageBubble";
import ChatInput from "./components/ChatInput";
import ProfileSection from "./components/ProfileSection";
import CameraModal from "./components/CameraModal";
import ScreenShareModal from "./components/ScreenShareModal";
import Profile from "./components/Profile";
import Login from "./Login";
import MobileFixerModal from "./components/MobileFixerModal";
import LoadingSpinner from "./components/LoadingSpinner";
import LiveVoiceModal from "./components/LiveVoiceModal";
import { useAuth } from "./AuthContext";
import { db, Timestamp, doc, setDoc, collection } from "./firebase";
import { useChatHistory } from "./hooks/useChatHistory";
import ChatHistorySidebar from "./components/ChatHistorySidebar";
import ExportButton from "./components/ExportButton";
import { geminiService } from "./lib/gemini";

interface Message {
  chat_id?: string;
  role: "user" | "model";
  content: string;
  timestamp?: string;
}

export default function App() {
  const { user, profile, loading, isAuthReady, updateProfileData } = useAuth();
  const {
    sessions,
    groupedSessions,
    messages,
    currentSessionId,
    setCurrentSessionId,
    saveMessage,
    deleteSession,
    renameSession,
    clearAll,
    searchQuery,
    setSearchQuery
  } = useChatHistory();
  
  const [isLoading, setIsLoading] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [isCameraModalOpen, setIsCameraModalOpen] = useState(false);
  const [isScreenShareModalOpen, setIsScreenShareModalOpen] = useState(false);
  const [isMobileFixerOpen, setIsMobileFixerOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isLiveVoiceOpen, setIsLiveVoiceOpen] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Initialize Dark Mode
  useEffect(() => {
    const savedDarkMode = localStorage.getItem("rohit_dark_mode") === "true";
    setIsDarkMode(savedDarkMode);
    if (savedDarkMode) document.documentElement.classList.add("dark");
    
    // Initial stats report
    geminiService.reportStats();
  }, []);

  // Scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const toggleDarkMode = () => {
    const newMode = !isDarkMode;
    setIsDarkMode(newMode);
    localStorage.setItem("rohit_dark_mode", newMode.toString());
    if (newMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  };

  const handleSend = async (userMessage: string, imageData?: string) => {
    if (isLoading || !profile) return;

    setIsLoading(true);

    // Save user message
    const userMsg = { 
      role: "user" as const, 
      content: userMessage || "[Image Shared]", 
      timestamp: user ? Timestamp.now() : new Date().toISOString() 
    };
    await saveMessage(userMsg);

    try {
      // Get last 10 messages for context
      const history = messages.slice(-10).map(m => ({
        role: m.role,
        content: m.content
      }));

      const aiReply = await geminiService.chat(userMessage, history, imageData);
      
      if (aiReply) {
        // Save AI reply
        const aiMsg = { 
          role: "model" as const, 
          content: aiReply, 
          timestamp: user ? Timestamp.now() : new Date().toISOString() 
        };
        await saveMessage(aiMsg);

        // Report stats to backend
        await geminiService.reportStats();

        // Update chat count and badge
        const newCount = profile.chatCount + 1;
        let newBadge = profile.badge;
        if (newCount >= 1000) newBadge = "Gold";
        else if (newCount >= 500) newBadge = "Silver";
        
        updateProfileData({ chatCount: newCount, badge: newBadge });
      }
    } catch (error) {
      console.error("Chat error:", error);
      // In a real app, you'd show an error message in the chat
    } finally {
      setIsLoading(false);
    }
  };

  const handleShareImageWithAI = (imageData: string) => {
    handleSend("", imageData);
  };

  const clearAllHistory = async () => {
    if (!confirm("Kya aap sach mein saari chat history delete karna chahte hain?")) return;
    await clearAll();
    setIsSidebarOpen(false);
  };

  const startNewChat = () => {
    setCurrentSessionId(null);
    setIsSidebarOpen(false);
  };

  if (loading || !isAuthReady) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-neutral-50 dark:bg-neutral-950">
        <LoadingSpinner />
      </div>
    );
  }

  if (!profile) {
    return <Login />;
  }

  return (
    <div className={`min-h-screen flex font-sans transition-colors duration-300 ${isDarkMode ? "bg-[#1A1A2E] text-neutral-100" : "bg-[#F8F9FA] text-neutral-900"}`}>
      {/* Sidebar */}
      <ChatHistorySidebar
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        sessions={groupedSessions}
        currentSessionId={currentSessionId}
        onSelectSession={setCurrentSessionId}
        onDeleteSession={deleteSession}
        onRenameSession={renameSession}
        onNewChat={() => setCurrentSessionId(null)}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
      />

      {/* Main Content */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden relative">
        {/* Background Gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-orange-500/5 via-transparent to-pink-500/5 pointer-events-none" />

        {/* Header */}
        <header className="bg-white/60 dark:bg-neutral-900/60 backdrop-blur-xl border-b border-white/20 dark:border-white/5 px-6 py-4 flex items-center justify-between sticky top-0 z-30 shadow-xl">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setIsSidebarOpen(true)}
              className="p-2 hover:bg-white/20 dark:hover:bg-black/20 rounded-full transition-colors text-neutral-600 dark:text-neutral-400"
            >
              <Menu size={24} />
            </button>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 premium-gradient rounded-full flex items-center justify-center text-white shadow-lg shadow-primary-start/20">
                <Sparkles size={24} />
              </div>
              <div className="hidden sm:block">
                <h1 className="text-xl font-black tracking-tight text-neutral-800 dark:text-neutral-100">Rohit X AI</h1>
                <p className="text-[10px] text-neutral-500 flex items-center gap-1 uppercase tracking-widest font-black">
                  <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></span>
                  Active Now
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={() => setIsLiveVoiceOpen(true)}
              className="p-2.5 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-full transition-all text-neutral-600 dark:text-neutral-400 hover:text-orange-500 dark:hover:text-orange-400"
              title="Live Voice Chat"
            >
              <Mic size={20} />
            </button>
            <div className="h-8 w-px bg-neutral-200 dark:bg-neutral-800 mx-1" />
            <button
              onClick={toggleDarkMode}
              className="p-2.5 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-full transition-all text-neutral-600 dark:text-neutral-400 hover:text-orange-500 dark:hover:text-orange-400"
            >
              {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
            </button>
            <div className="h-8 w-px bg-neutral-200 dark:bg-neutral-800 mx-1" />
            <ExportButton messages={messages} title={sessions.find(s => s.id === currentSessionId)?.title || "Rohit_AI_Chat"} />
            <div className="h-8 w-px bg-neutral-200 dark:bg-neutral-800 mx-1" />
            <div onClick={() => setIsProfileOpen(true)} className="cursor-pointer">
              <ProfileSection userId={profile.uid} />
            </div>
          </div>
        </header>

        {/* Chat Area */}
        <main className="flex-1 overflow-y-auto p-4 md:p-8 max-w-4xl mx-auto w-full space-y-2 relative scroll-smooth">
          {messages.length === 0 && !isLoading && (
            <div className="flex flex-col items-center justify-center h-full text-center space-y-6 py-20">
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="w-24 h-24 bg-gradient-to-br from-orange-100 to-pink-100 dark:from-orange-900/20 dark:to-pink-900/20 rounded-full flex items-center justify-center text-orange-600 dark:text-orange-400 mb-4 shadow-inner"
              >
                <Smile size={56} />
              </motion.div>
              <div className="space-y-2">
                <h2 className="text-3xl font-black text-neutral-800 dark:text-neutral-100 tracking-tight">Namaste! Main Rohit hoon.</h2>
                <p className="text-neutral-600 dark:text-neutral-400 max-w-md mx-auto text-lg">
                  Main aapka Indian AI dost hoon. Aap mujhse kisi bhi cheez ke baare mein baat kar sakte hain. 
                </p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full max-w-xl mt-8">
                {[
                  { icon: "😂", text: "Ek mast joke sunao" },
                  { icon: "😔", text: "Aaj main thoda sad hoon" },
                  { icon: "📱", text: "Mobile tips chahiye" },
                  { icon: "📖", text: "Koi story sunao" }
                ].map((suggestion) => (
                  <button
                    key={suggestion.text}
                    onClick={() => handleSend(suggestion.text)}
                    className="p-4 text-sm text-left border border-neutral-200 dark:border-neutral-800 rounded-2xl hover:border-orange-400 dark:hover:border-orange-500 hover:bg-orange-50 dark:hover:bg-orange-900/10 transition-all text-neutral-700 dark:text-neutral-300 flex items-center gap-3 group shadow-sm bg-white dark:bg-neutral-900"
                  >
                    <span className="text-xl group-hover:scale-125 transition-transform">{suggestion.icon}</span>
                    <span className="font-medium">{suggestion.text}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="space-y-2">
            {messages.map((msg, idx) => (
              <MessageBubble
                key={idx}
                msg={msg}
              />
            ))}
          </div>

          {isLoading && (
            <motion.div
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex justify-start mb-6"
            >
              <div className="flex gap-3">
                <div className="w-9 h-9 premium-gradient rounded-full flex items-center justify-center text-white animate-pulse shadow-md">
                  <Sparkles size={18} />
                </div>
                <div className="bg-white/80 dark:bg-neutral-800/80 backdrop-blur-md border border-white/20 dark:border-white/5 p-4 rounded-2xl rounded-tl-none shadow-sm flex gap-1.5 items-center">
                  <span className="typing-dot"></span>
                  <span className="typing-dot"></span>
                  <span className="typing-dot"></span>
                </div>
              </div>
            </motion.div>
          )}
          <div ref={messagesEndRef} className="h-4" />
        </main>

        {/* Input Area */}
        <ChatInput
          onSend={handleSend}
          isLoading={isLoading}
          isDarkMode={isDarkMode}
          onOpenCamera={() => setIsCameraModalOpen(true)}
          onOpenScreenShare={() => setIsScreenShareModalOpen(true)}
          onOpenMobileFixer={() => setIsMobileFixerOpen(true)}
        />
      </div>

      {/* Modals */}
      <CameraModal
        isOpen={isCameraModalOpen}
        onClose={() => setIsCameraModalOpen(false)}
        onShareWithAI={handleShareImageWithAI}
      />
      <ScreenShareModal
        isOpen={isScreenShareModalOpen}
        onClose={() => setIsScreenShareModalOpen(false)}
        onShareWithAI={handleShareImageWithAI}
      />
      <MobileFixerModal
        isOpen={isMobileFixerOpen}
        onClose={() => setIsMobileFixerOpen(false)}
      />
      <LiveVoiceModal
        isOpen={isLiveVoiceOpen}
        onClose={() => setIsLiveVoiceOpen(false)}
      />
      <Profile
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
      />
    </div>
  );
}
